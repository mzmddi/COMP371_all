#ifndef GEOMETRY_H
#define GEOMETRY_H

// ---INCLUDE---

#include <Eigen/Core>

#include "Ray.h"
#include "HitRecord.h"

// ---CODE---

class Geom
{

    std::string type;
    // type of the geometry
    // mandatory

    float ka;
    float kd;
    float ks;
    // ambient, diffuse, specular reflection coefficient
    // mandatory

    float pc;
    // phong coefficient
    // mandatory

    Eigen::Vector3f ac;
    Eigen::Vector3f dc;
    Eigen::Vector3f sc;
    // ambient, diffuse, specular reflection color (rgb)
    // mandatory

    Eigen::Matrix4f transform = Eigen::Matrix4f::Identity();
    // affine transformation matrix in row major representation
    // optional
    // initialized as an identity matrix so that i can use it regardless if the json file input defines it or not
    // if the json file does not define this, then it will stay an identity matrix, and the computations with this wont change anything

public:
    Geom() {};
    // constructor for virtual class

    std::string get_type() const { return type; };
    float get_ka() const { return ka; };
    float get_kd() const { return kd; };
    float get_ks() const { return ks; };
    float get_pc() const { return pc; };
    Eigen::Vector3f get_ac() const { return ac; };
    Eigen::Vector3f get_dc() const { return dc; };
    Eigen::Vector3f get_sc() const { return sc; };
    Eigen::Matrix4f get_transform() const { return transform; };
    // all of the getters defined and implement in one shot

    void set_type(std::string s) { type = s; };
    void set_ka(float s) { ka = s; };
    void set_kd(float s) { kd = s; };
    void set_ks(float s) { ks = s; };
    void set_pc(float s) { pc = s; };
    void set_ac(Eigen::Vector3f s) { ac = s; };
    void set_dc(Eigen::Vector3f s) { dc = s; };
    void set_sc(Eigen::Vector3f s) { sc = s; };
    void set_transform(Eigen::Matrix4f s) { transform = s; };
    // all of the setters defined and implemented

    virtual bool intersect(const Ray &r, float &t_min, float &closest_t, HitRecord &hit) = 0;
    virtual void test() = 0;
    // virtual methods that ill implement in the child classes

    virtual ~Geom() = default;
    // destructor for the virtual class
};

class Sphere : public Geom
{

    float radius;
    Eigen::Vector3f centre;
    // members specifically for spheres

public:
    Sphere() : Geom() {};

    float get_radius() const { return this->radius; };
    Eigen::Vector3f get_centre() const { return this->centre; };
    // additional getters for sphere since not present in parent class

    void set_radius(float s) { radius = s; }
    void set_centre(Eigen::Vector3f s) { centre = s; }
    // additional setters for sphere

    bool intersect(const Ray &r, float &t_min, float &closest_t, HitRecord &hit) override;
    // intersection for sphere specifically

    void test() override;
};

class Rectangle : public Geom
{

    Eigen::Vector3f p1;
    Eigen::Vector3f p2;
    Eigen::Vector3f p3;
    Eigen::Vector3f p4;
    // 4 corners of the rectangle in counterclockwise order with respect to the normal. 4 points assumed to be coplanar.
    // (from the assignment pdf document)

    Eigen::Vector3f n;
    // surface normal of the rectangle
    // not given to use from the json, but will eventually be calculated

public:
    Rectangle() : Geom() {};

    Eigen::Vector3f get_p1() const { return this->p1; };
    Eigen::Vector3f get_p2() const { return this->p2; };
    Eigen::Vector3f get_p3() const { return this->p3; };
    Eigen::Vector3f get_p4() const { return this->p4; };
    Eigen::Vector3f get_n() const { return this->n; };
    // all the additional getters for rec

    void set_p1(Eigen::Vector3f s) { this->p1 = s; }
    void set_p2(Eigen::Vector3f s) { this->p2 = s; }
    void set_p3(Eigen::Vector3f s) { this->p3 = s; }
    void set_p4(Eigen::Vector3f s) { this->p4 = s; }
    void set_n(Eigen::Vector3f s) { this->n = s; }
    // additional setters for rec

    bool intersect(const Ray &r, float &t_min, float &closest_t, HitRecord &hit) override;
    // intersect with rec

    void test() override;
};

#endif